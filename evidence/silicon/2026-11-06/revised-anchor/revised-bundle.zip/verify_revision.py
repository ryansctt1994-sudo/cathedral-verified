"""Verify a source publication receipt. This cannot qualify a physical board."""
from pathlib import Path
import argparse
import base64
import hashlib
import json

from source.chronicle.chronicle import Chronicle, make_anchor
from source.chronicle.external_anchor import require, strict_json, verify_anchor

ORIGINAL_SHA256 = 'cfbc72137d476a7c89817ba5e12f0104aa3e3b5be35079f8be295743a83fbd78'
PACKET_PATH = 'source/hardware/lucifer_latch/arty_a7/qualification/packet.sha256'


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


def verify(directory, expected_checkpoint_sha256, expected_source_commit):
    directory = Path(directory).resolve()
    def read(path):
        resolved = (directory / path).resolve()
        require(resolved.is_relative_to(directory), 'path escapes evidence bundle')
        return resolved.read_bytes()

    raw = read('checkpoint.json')
    require(sha(raw) == expected_checkpoint_sha256, 'wrong expected checkpoint')
    checkpoint = strict_json(raw)
    current = verify_anchor(raw, strict_json(read('rekor-entry.json')), read('rekor-public-key.pem'))
    readback = verify_anchor(raw, strict_json(read('rekor-readback.json')), read('rekor-public-key.pem'))
    require(current['uuid'] == readback['uuid'], 'readback belongs to a different entry')

    old_raw = read('previous/checkpoint.json')
    require(sha(old_raw) == ORIGINAL_SHA256, 'wrong original checkpoint')
    previous = verify_anchor(old_raw, strict_json(read('previous/rekor-entry.json')),
                             read('previous/rekor-public-key.pem'))
    def author_key(entry_path):
        entry = next(iter(strict_json(read(entry_path)).values()))
        body = strict_json(base64.b64decode(entry['body'], validate=True))
        return base64.b64decode(body['spec']['signature']['publicKey']['content'], validate=True)
    require(author_key('rekor-entry.json') == author_key('previous/rekor-entry.json'),
            'author key continuity mismatch')
    old_checkpoint = strict_json(old_raw)
    old_ledger = read('previous/qualification.chronicle.jsonl')
    new_ledger = read('qualification.chronicle.jsonl')
    require(new_ledger.startswith(old_ledger), 'original ledger prefix changed')
    # Reject duplicate JSON fields before the original Chronicle loader reads them.
    for line in new_ledger.splitlines():
        strict_json(line)
    old_chain = Chronicle(str(directory / 'previous/qualification.chronicle.jsonl'))
    new_chain = Chronicle(str(directory / 'qualification.chronicle.jsonl'))
    require(old_chain.verify()[0] and new_chain.verify()[0], 'invalid Chronicle chain')
    require(make_anchor(old_chain) == old_checkpoint['anchor'], 'original anchor mismatch')
    require(make_anchor(new_chain) == checkpoint['anchor'], 'revised anchor mismatch')
    require(len(new_chain.entries) == len(old_chain.entries) + 1, 'expected one appended revision')
    reference = {'checkpoint_sha256': ORIGINAL_SHA256, 'ledger_sha256': sha(old_ledger),
                 'rekor_entry_url': previous['entry_url'], 'rekor_log_index': previous['log_index'],
                 'anchor': make_anchor(old_chain)}
    require(checkpoint['previous_checkpoint'] == reference, 'prior checkpoint link mismatch')
    payload = new_chain.entries[-1].payload
    require(payload['previous_checkpoint'] == reference, 'appended entry prior link mismatch')
    require(payload['event'] == 'LUCIFER_REVISED_RTL_PACKET_CANDIDATE', 'wrong record scope')

    source_raw = read('source-manifest.json')
    require(sha(source_raw) == checkpoint['source_manifest_sha256'], 'source manifest mismatch')
    source = strict_json(source_raw)
    require(source['commit'] == checkpoint['source_commit'] == expected_source_commit,
            'wrong source commit')
    require(source['tree'] == checkpoint['source_tree'], 'source tree mismatch')
    require(payload['source'] == {'commit': source['commit'], 'tree': source['tree'],
                                 'repository': source['repository']}, 'entry source mismatch')
    require(source['artifact_count'] == len(source['artifacts']), 'artifact count mismatch')
    paths = [artifact['path'] for artifact in source['artifacts']]
    require(len(paths) == len(set(paths)), 'duplicate source artifact')
    require(all(path.startswith('source/') for path in paths), 'invalid source path')
    expected = source['artifacts'] + [{'path': 'source-manifest.json',
                                      'sha256': sha(source_raw), 'size': len(source_raw)}]
    require(payload['artifacts'] == expected, 'artifact inventory mismatch')
    for artifact in expected:
        data = read(artifact['path'])
        require(sha(data) == artifact['sha256'] and len(data) == artifact['size'],
                'artifact mismatch: ' + artifact['path'])
    packet = read(PACKET_PATH)
    require(sha(packet) == source['packet_checksum_list_sha256']
            == checkpoint['packet_checksum_list_sha256'], 'packet hash mismatch')
    packet_count = 0
    for line in packet.decode('utf-8').splitlines():
        digest, path = line.split('  ', 1)
        require('source/' + path in paths, 'packet file missing from source manifest')
        require(sha(read('source/' + path)) == digest, 'packet file mismatch: ' + path)
        packet_count += 1
    claims = checkpoint['claims']
    require(payload['claims'] == claims, 'claim mismatch')
    require(claims['status'] == 'NOT_READY' and claims['E3_1_earned'] is False
            and claims['production_authority_earned'] is False, 'unexpected qualification claim')
    return {'verification': 'VERIFIED_REVISED_SOURCE_PUBLICATION',
            'checkpoint_sha256': expected_checkpoint_sha256, 'source_commit': expected_source_commit,
            'rekor_entry_url': current['entry_url'], 'log_index': current['log_index'],
            'source_artifacts_verified': len(paths), 'packet_files_verified': packet_count,
            'chronicle_entries': len(new_chain.entries), 'original_prefix_preserved': True,
            'original_and_revised_inclusion_verified': True, 'retained_readback_verified': True,
            'author_key_continuity_verified': True,
            'rekor_tree_consistency_proof': 'NOT_VERIFIED', 'full_TUF_chain': 'NOT_VERIFIED',
            'independent_witnessing': False, 'silicon_E3_1': 'NOT_READY',
            'production_authority_earned': False}


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--directory', type=Path, default=Path(__file__).resolve().parent)
    parser.add_argument('--checkpoint-sha256', required=True)
    parser.add_argument('--source-commit', required=True)
    args = parser.parse_args()
    print(json.dumps(verify(args.directory, args.checkpoint_sha256, args.source_commit), indent=2))
