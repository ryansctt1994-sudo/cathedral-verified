from pathlib import Path
from datetime import datetime,timezone
import sys,json,hashlib,copy,shutil,tempfile
original=Path(__file__).resolve().parent
working=tempfile.TemporaryDirectory(prefix='lucifer-anchor-mutations-')
root=Path(working.name)/'bundle'
shutil.copytree(original,root,ignore=shutil.ignore_patterns('__pycache__'))
sys.path.insert(0,str(root))
from verify_revision import verify
from source.chronicle.external_anchor import canonical
expected='b0439f7d0878dd8d888bd7fde2dc37baca645829d10e999609c79b38a3018332'
commit='0f3b0973b95ecbadb49ca4f7d989ed1da8a2f6b9'
verify(root,expected,commit)
cases=[]
def mutation(name,path,change):
 p=root/path;raw=p.read_bytes()
 try:
  p.write_bytes(change(raw))
  try:
   verify(root,expected,commit)
  except Exception as e:
   cases.append({'case':name,'result':'REJECTED','error_type':type(e).__name__,'reason':str(e)})
  else:raise AssertionError('Mutation accepted: '+name)
 finally:p.write_bytes(raw)
mutation('revised RTL bytes changed','source/hardware/lucifer_latch/arty_a7/lucifer_arty_a7.v',lambda raw:raw+b'\n// changed\n')
mutation('original ledger prefix edited','qualification.chronicle.jsonl',lambda raw:raw.replace(b'LUCIFER_BUILD_CANDIDATE',b'LUCIFER_FALSE_CANDIDATE',1))
mutation('original checkpoint link metadata altered','checkpoint.json',lambda raw:raw.replace(b'3719860200',b'3719860201',1))
def corrupt_signature(raw):
 d=json.loads(raw);entry=next(iter(d.values()));s=entry['verification']['signedEntryTimestamp'];entry['verification']['signedEntryTimestamp']=('A' if s[0]!='A' else 'B')+s[1:];return canonical(d)
mutation('old public log signature corrupted','previous/rekor-entry.json',corrupt_signature)
mutation('new public readback signature corrupted','rekor-readback.json',corrupt_signature)
verify(root,expected,commit)
report={'schema':'revised-anchor-verifier-checks/1','observed_at_utc':datetime.now(timezone.utc).isoformat(),'positive_original_restored':'VERIFIED','cases':cases,'synthetic_local_mutations_only':True,'independent_observation':False,'production_authority_earned':False}
(original/'verifier-checks.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'positive_verification':'PASS','mutations_rejected':len(cases),'bytes_restored':True},indent=2))

working.cleanup()
